# University-Management-System
University Management System using OOP in Java (GUI) without database.
In this project just view the screens of both student portal and admin portal.
Project owned by Muhammad Khaqan Nasir student of COMSATS University Islamabad,Sahiwal Campus.
Project execution start with the MainFrame.java class.
Student Portal [reg no. = FA22-BCS-039 , password = 1234].
Admin Portal [username = admin , password = 1234].
#Java #GUI #ManagementSystem #shortproject #oop #UniversityManagementSystem #miniproject
