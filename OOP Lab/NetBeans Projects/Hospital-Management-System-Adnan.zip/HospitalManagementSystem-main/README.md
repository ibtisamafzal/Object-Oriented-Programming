# HospitalManagementSystem
This was my semester project for the course Object Oriented Programming. I designed a GUI-based Hospital Management System using Java and integrated it with MySQL database. It consists of Doctor, Patient, and Booking Appointment modules with properties like viewing from the database. It was a team-based project that I lead.
