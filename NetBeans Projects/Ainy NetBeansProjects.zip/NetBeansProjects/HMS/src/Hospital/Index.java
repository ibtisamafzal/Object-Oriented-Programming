package Hospital;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Index extends JFrame implements ActionListener
{
    JFrame f;
    JLabel l1,l2,l3,l4;
    JButton b1,b2,b3,b4;
    
    Index()
    {
        f=new JFrame("Index Page");
        f.setBackground(Color.WHITE);
        f.setLayout(null);
        f.
        
        l1=new JLabel();
        l1.setBounds(0,0,800,570);
        
        
    }

  
   

}
