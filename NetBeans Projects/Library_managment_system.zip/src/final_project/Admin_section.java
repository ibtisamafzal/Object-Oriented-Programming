package final_project;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Admin_section {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame4 = new JFrame("Admin Section");
        JButton Add_Libraian = new JButton("Add Libraian");
        JButton view_Libraian = new JButton("View_Libraian");
        JButton Delete_Libraian = new JButton("Delete_Libraian");
        JButton logout = new JButton("Logout");
        JLabel Admin_Section = new JLabel("Admin Section");
       
       	 frame4.setVisible(true);
       	 frame4.setLayout(null);
       	 frame4.setSize(400,400);
       	 frame4.getContentPane().setBackground(Color.blue);
            frame4.add(Add_Libraian);
            frame4.add(Delete_Libraian);
            frame4.add(logout);
            frame4.add(view_Libraian);
            frame4.add(Admin_Section);
            Add_Libraian.setBounds(100,60,200,40);
            view_Libraian.setBounds(100,130,200,40);;
            Delete_Libraian.setBounds(100,200,200,40);
            logout.setBounds(100,270,200,40);
            Admin_Section.setBounds(140,10,200,40);
            Admin_Section.setForeground(Color.orange);
            Admin_Section.setFont(new Font("Arial",Font.BOLD, 18));
            Add_Libraian.setBackground(Color.ORANGE);
            view_Libraian.setBackground(Color.orange);
            Delete_Libraian.setBackground(Color.orange);
            logout.setBackground(Color.orange);
            Add_Libraian.addActionListener(new ActionListener() {
  	          @Override
  	           public void actionPerformed(ActionEvent e) {
  	        	Add_Libraian   m = new Add_Libraian ();
  	               m.main(args);
  	               frame4.setVisible(false);
  	             
  	           
  	   }}); 
            logout.addActionListener(new ActionListener() {
		          @Override
		           public void actionPerformed(ActionEvent e) {
		        	  main_page  n = new main_page();
		               n.main(args);
		               frame4.setVisible(false);
		           
		   }});       
	

            
            

	}

}
