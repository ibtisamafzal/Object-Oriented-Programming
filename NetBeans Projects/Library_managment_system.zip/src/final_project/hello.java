package final_project;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.color.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class hello{

    public static void main(String[] args){
		JFrame frame1 = new JFrame("Welocme");
		 
	       JButton first_button = new JButton("Start");
	       JLabel label1 = new JLabel("Welcome to Sigma Library");

	   // for display first frame
	    
	   
	       frame1.setVisible(true);
	       frame1.setSize(400,400);
	       frame1.setLayout(null);
	       frame1.add(first_button);
	       frame1.add(label1);
	       label1.setBounds(100,100,300,150);
	       first_button.setBounds(230,340,150,50);
	       label1.setForeground(Color.orange);
	       frame1.getContentPane().setBackground(Color.blue);
	       first_button.setBackground(Color.orange);
	       label1.setFont(new Font("Arial",Font.BOLD, 18));
	       first_button.addActionListener(new ActionListener() {
	          @Override
	           public void actionPerformed(ActionEvent e) {
	               main_page m = new main_page();
	               m.main(args);
	               frame1.setVisible(false);
	           
	   }});       
	   
	   
}
}