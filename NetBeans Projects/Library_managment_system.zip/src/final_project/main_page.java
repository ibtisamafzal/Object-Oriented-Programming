package final_project;
import java.awt.Color;
import libraian;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
public class main_page {

	public static void main(String[] args) 
	{
	       JFrame frame2 = new JFrame("Login");
	       
	       JButton admin = new JButton("Admin Login ");
	       JButton Libraian = new JButton("Libraian Login");
	        frame2.setVisible(true);
	          frame2.setLayout(null);
	         frame2.setSize(400,400);
	          frame2.getContentPane().setBackground(Color.blue);
	          admin.setBounds(100, 100, 200,70);
	          Libraian.setBounds(100,230,200,70);
	          frame2.add(admin);
	         frame2.add(Libraian);
	         admin.setBackground(Color.orange);
	          Libraian.setBackground(Color.orange);
	         
	          admin.addActionListener(new ActionListener() {
		          @Override
		           public void actionPerformed(ActionEvent e) {
		        	  Adminlogin  m = new Adminlogin();
		               m.main(args);
		               frame2.setVisible(false);
		           
		   }});       
	          
		
	          Libraian .addActionListener(new ActionListener() {
		          @Override
		           public void actionPerformed(ActionEvent e) {
		        	  libraian n = new libraian();
		               n.main(args);
		               frame2.setVisible(false);
		           
		   }});       
	

	}

}

