package final_project;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class issue_book {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame frame10 = new JFrame("Issue Book");
		JLabel bookcallno = new JLabel("Book callno");
		JLabel l1 = new JLabel("Book Issue");
		JLabel Std_Id = new JLabel("Student Id");
		JLabel  std_name = new JLabel("Student Name");
		JLabel std_cont = new JLabel("Admin Section");
		JTextField atext1 = new JTextField();
        JTextField atext2 = new JTextField();
        JTextField atext3 = new JTextField();
        JTextField atext4 = new JTextField();
        JButton alog = new JButton("Issue book");
		frame10.add(alog);
		frame10.add(atext4);
		frame10.add(atext3);
		frame10.add(atext2);
		frame10.add(atext1);
		frame10.add(std_cont);
		frame10.add(std_name);
		frame10.add(bookcallno);
		frame10.add(Std_Id);
		frame10.add(std_name);
		frame10.add(l1);
		l1.setBounds(150,20,100,30);
		 frame10.getContentPane().setBackground(Color.blue);
		 frame10.setLayout(null);
		 frame10.setSize(400,400);
		 frame10.setVisible(true);
		 l1.setForeground(Color.ORANGE);
		 bookcallno.setBounds(50,50,100,40);
		 bookcallno.setForeground(Color.orange);
		 atext1.setBounds(150,50,170,40);
		 Std_Id.setBounds(50,100,100,40);
		 Std_Id.setForeground(Color.orange);
		 std_name.setBounds(50,150,100,40);
		 std_name.setForeground(Color.orange);
		 atext2.setBounds(150,100,170,40);
		 std_cont.setBounds(50,200,100,40);
		 atext3.setBounds(150,150,170,40);
		 atext4.setBounds(150,200,170,40);
		 std_cont.setForeground(Color.orange);
		 alog.setBounds(150,270,150,40);
		 alog.setBackground(Color.orange);
		 
		 alog.addActionListener(new ActionListener() {
	          @Override
	           public void actionPerformed(ActionEvent e) {
	        	  libraian_main n = new libraian_main();
	               n.main(args);
	               frame10.setVisible(false);
	           
	   }});  
		 
		
}
}