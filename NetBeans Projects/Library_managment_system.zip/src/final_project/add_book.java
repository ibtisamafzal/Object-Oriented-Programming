package final_project;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class add_book {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame frame9 = new JFrame("Add Book");
		frame9.setVisible(true);
		frame9.setLayout(null);
		frame9.setSize(400,400);
		frame9.getContentPane().setBackground(Color.blue);
		 JLabel Add_book = new JLabel("Add Books");
		 Add_book.setFont(new Font("Arial",Font.BOLD, 18));
		 JLabel name= new JLabel("Name");
		 JLabel Author_name = new JLabel("Author Books");
		 JLabel publisher = new JLabel("Publisher");
		 JLabel Contact_no= new JLabel("Contact No");
		 JLabel Quantity = new JLabel("Quantity");
		 JTextField text1 = new JTextField();
		 JTextField text2 = new JTextField();
		 JTextField text3 = new JTextField();
		 JTextField text4 = new JTextField();
		 JTextField text5 = new JTextField();
		JButton a_book = new JButton("Add Books");
	     JButton back = new JButton("Back");
	     frame9.add(back);
	     frame9.add(a_book);
	     frame9.add(text5);
	     frame9.add(text4);
	     frame9.add(text3);
	     frame9.add(text2);
	     frame9.add(text1);
	     frame9.add(Quantity);
	     frame9.add(Contact_no);
	     frame9.add(publisher);
	     frame9.add(Author_name);
	     frame9.add(name);
	     frame9.add(Add_book);
	     
	     Add_book.setBounds(150,5, 200,40);
	     Add_book.setForeground(Color.orange);
	     name.setBounds(50,50,100,40);
	     text1.setBounds(120,50,200,30);
	     Author_name.setForeground(Color.orange);
	     name.setForeground(Color.orange);
	     Author_name.setBounds(30,90,100,40);
	     text2.setBounds(120,90,200,30);
	     publisher.setForeground(Color.orange);
	     publisher.setBounds(40,130,100,40);
	     text3.setBounds(120,130,200,30);
	     Contact_no.setForeground(Color.orange);
	     Contact_no.setBounds(30,170,100,40);
	     text4.setBounds(120,170,200,30);
	     Quantity.setBounds(30,210,100,40);
	    text5.setBounds(120,210,200,30);
	    Quantity.setForeground(Color.orange);
	    a_book.setBounds(140,270,150,40);
	    a_book.setBackground(Color.orange);
	    a_book.addActionListener(new ActionListener() {
	          @Override
	           public void actionPerformed(ActionEvent e) {
	        	  libraian_main n = new libraian_main();
	               n.main(args);
	               frame9.setVisible(false);
	           
	   }});       

	}
	
	}
