package final_project;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class libraian_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		JFrame frame8 = new JFrame("Libraian Section");
		frame8.setVisible(true);
        frame8.setLayout(null);
        frame8.getContentPane().setBackground(Color.blue);
        frame8.setSize(400,400);
        JLabel l1 = new JLabel("Libraian Section");
        l1.setFont(new Font("Arial",Font.BOLD, 20));
		JButton add_book = new JButton("Add Books");
		JButton view_book = new JButton("View Books");
		JButton issue_book= new JButton("Issue Book");
		JButton ihistory = new JButton("View Issued Book");
		JButton return_book= new JButton("Return_book");
		JButton logout = new JButton("Log out");
		frame8.add(add_book);
		frame8.add(view_book);
		frame8.add(ihistory);
		frame8.add(return_book);
		frame8.add(logout);
		frame8.add(issue_book);
		frame8.add(l1);
		l1.setBounds(130,20,200,50);
		l1.setForeground(Color.orange);
		add_book.setBounds(130,80,150,40);
		view_book.setBounds(130, 140,150,40);
		issue_book.setBounds(130,200,150,40);
		ihistory.setBounds(130,255,150,40);
		return_book.setBounds(130,310,150,40);
		logout.setBounds(260,360,140,40);
		add_book.setBackground(Color.orange);
		view_book.setBackground(Color.orange);
		issue_book.setBackground(Color.orange);
		ihistory.setBackground(Color.orange);
		return_book.setBackground(Color.orange);
		logout.setBackground(Color.orange);
		
		 logout.addActionListener(new ActionListener() {
	          @Override
	           public void actionPerformed(ActionEvent e) {
	        	  main_page  n = new main_page();
	               n.main(args);
	               frame8.setVisible(false);
	           
	   }}); 
		 add_book.addActionListener(new ActionListener() {
	          @Override
	           public void actionPerformed(ActionEvent e) {
	        	  add_book  n = new add_book();
	               n.main(args);
	               frame8.setVisible(false);
	           
	   }});  
		 
		 issue_book.addActionListener(new ActionListener() {
	          @Override
	           public void actionPerformed(ActionEvent e) {
	        	  issue_book  n = new issue_book();
	               n.main(args);
	               frame8.setVisible(false);
	           
	   }});  
		  

		
	}

}
