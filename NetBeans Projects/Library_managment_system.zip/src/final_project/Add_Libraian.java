package final_project;
import java.awt.Color;
import java.awt.*;
import Admin_section;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class Add_Libraian {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
		JFrame frame5 = new JFrame("Add Libraian");
        JLabel Add_libry = new JLabel("Add Libraian");
        JButton Add_librarian = new JButton("Add_librarian");
        JButton back = new JButton("back");
        JLabel name = new JLabel("Name:");
        JLabel password = new JLabel("password:");
        JLabel e_mail = new JLabel("E-Mail");
        JLabel address = new JLabel("Address:");
        JLabel city  = new JLabel("City");
        JLabel contact = new JLabel("Contact No");
        JTextField passwordt = new JTextField ();
        JTextField text1 = new JTextField();
        JTextField text2 = new JTextField();
        JTextField text3 = new JTextField();
        JTextField text4 = new JTextField();
        JTextField text5 = new JTextField();
        
          frame5.setVisible(true);
        	frame5.setLayout(null);
        	frame5.setSize(400,400);
        	frame5.getContentPane().setBackground(Color.blue);
        	frame5.add(Add_librarian);
        	frame5.add(Add_libry);
        	frame5.add(address);
        	frame5.add(back);
        	frame5.add(city);
        	frame5.add(contact);
        	frame5.add(e_mail);
        	frame5.add(name);
        	frame5.add(password);
        	frame5.add(text1);
        	frame5.add(text2);
        	frame5.add(text3);
        	frame5.add(text4);
        	frame5.add(text5);
        	frame5.add(passwordt);
        	Add_libry.setBounds(130,0,200,90);
        	Add_libry.setFont(new Font("Arial",Font.BOLD, 20));
        	Add_libry.setForeground(Color.orange);
            name.setBounds(40,55,100,50);
            name.setForeground(Color.orange);
            text1.setBounds(120,70,150,20);
            password.setBounds(39,110,100,20);
           password.setForeground(Color.orange);	        	
           passwordt.setBounds(120,110,150,20);
           e_mail.setBounds(40,137,100,50);
           e_mail.setForeground(Color.orange);
           text2.setBounds(120,150,150,20);
           address.setBounds(39,190,150,20);
           address.setForeground(Color.orange);
           text3.setBounds(120,190,150,20);
           city.setBounds(43,230,50,20);
           city.setForeground(Color.ORANGE);
           text4.setBounds(120,230,150,20);
           contact.setBounds(40,270,150,20);
           contact.setForeground(Color.orange);
           text5.setBounds(120,270,150,20);
           Add_librarian.setBounds(130,310,120,45);
           Add_librarian.setBackground(Color.orange);
           back.setBounds(10,5,70,35);
           back.setBackground(Color.orange);
           back.addActionListener(new ActionListener() {
		          @Override
		           public void actionPerformed(ActionEvent e) {
		        	  Admin_section  m = new  Admin_section();
		               m.main(null);
		               frame5.setVisible(false);
		           
		   }});   
           Add_librarian.addActionListener(new ActionListener() {
		          @Override
		           public void actionPerformed(ActionEvent e) {
		        	  Admin_section  m = new  Admin_section();
		               m.main(null);
		               frame5.setVisible(false);
		          }});
	}
}
		
		
	
		

