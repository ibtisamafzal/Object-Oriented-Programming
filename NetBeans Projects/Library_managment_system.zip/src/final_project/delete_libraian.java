package final_project;
import java.awt.Color;

import javax.swing.*;
public class delete_libraian {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame11 = new JFrame("Delete Librarian");
		JLabel label11 = new JLabel("Librarian ID");
		JLabel label12 = new JLabel("Delete Librarian");
		JTextField text11 = new JTextField();
		JButton buton = new JButton("Delete");
		
		
		frame11.setVisible(true);
	    frame11.setSize(400,400);
	    frame11.setLayout(null);
	    frame11.add(label11);
	    frame11.add(text11);
	    frame11.add(buton);
	    frame11.add(label12);
	    
	    label11.setBounds(90, 70, 100, 40);
	    text11.setBounds(170, 70, 150, 40);
	    label12.setBounds(150, 20, 100, 40);
	    
	    
	    label12.setForeground(Color.orange);
	    label11.setForeground(Color.orange);
	    frame11.getContentPane().setBackground(Color.blue);
	    
	}

}
