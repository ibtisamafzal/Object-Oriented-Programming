package final_project;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
public class Adminlogin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame  frame3 = new JFrame("Admin login");
        JButton alog = new JButton("log in");
        JLabel aname = new JLabel("Enter your name");
        JLabel apass = new JLabel("Enter your password");
        JLabel adm = new JLabel("Admin Login Form");
        JTextField atext1 = new JTextField();
        JTextField atext2 = new JTextField();
       frame3.setVisible(true);
	   frame3.setLayout(null);
	   frame3.setSize(400,400);
	   frame3.getContentPane().setBackground(Color.blue);
	   frame3.add(adm);
	   frame3.add(alog);
	   frame3.add(aname);
	   frame3.add(apass);
	   frame3.add(atext1);
	   frame3.add(atext2);
	   aname.setBounds(30,150,200,50);
	   aname.setForeground(Color.orange);
	   atext1.setBounds(150, 150,170, 40);
	   apass.setForeground(Color.orange);
	   apass.setBounds(20,230,200,50);
	   atext2.setBounds(150,230,170,40);
       alog.setBounds(153,310,160,40);
       alog.setBackground(Color.orange);
       adm.setBounds(140,60,200,40);
       adm.setForeground(Color.orange);	
       adm.setFont(new Font("Arial",Font.BOLD, 20));
      alog.addActionListener(new ActionListener() {


    	    @Override
    	    public void actionPerformed(ActionEvent e) {
    	    	Admin_section m = new Admin_section();
        	    String t1 = atext1.getText();
        	    String t2 = atext2.getText();
        	    String n ="zain";
        	    String p = "zain1234";
    	        if ((t1.equals(n))&&(t2.equals(p)))
    	        		{
    	        		m.main(args);
    	            frame3.setVisible(false);
    	        } 
    	        else 
    	        {
    	        	 JOptionPane.showMessageDialog(frame3, "Invalid Password and Username");
    	        }
    	       
    	       
    	    }
  	});
      
      

	}

}
