package final_project;
import java.awt.Color;
import libraian_main;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class libraian {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        JFrame frame6 = new JFrame("Libraian login");
        JButton llogin = new JButton("log in");
        JLabel l3 =  new JLabel("Libraian Login Form");
        JLabel l1 =  new JLabel("Enter your Name");
        JLabel l2 =  new JLabel("Enter your password");
        JTextField text1 = new JTextField();
        JTextField text2 = new JTextField();
        frame6.add(l1);
        frame6.add(l2);
        frame6.add(llogin);
        frame6.add(text1);
        frame6.add(text2);
        frame6.add(l3);
        frame6.setSize(400,400);
        frame6.setLayout(null);
        frame6.getContentPane().setBackground(Color.blue);
        frame6.setVisible(true);
        l1.setBounds(30,150,200,50);
        l1.setForeground(Color.ORANGE);
        l2.setBounds(20,230,200,50);
        l2.setForeground(Color.ORANGE);
        text1.setBounds(150, 150,170, 40);
        text2.setBounds(150,230,170,40);
        l3.setFont(new Font("Arial",Font.BOLD, 20));
        l3.setBounds(130,60,200,40);
        l3.setForeground(Color.orange);
        llogin.setBounds(170,310,120,40);
        llogin.setBackground(Color.orange);
        llogin .addActionListener(new ActionListener() {
	          @Override
	           public void actionPerformed(ActionEvent e) {
	        	  libraian_main m = new  libraian_main();
	               m.main(args);
	               frame6.setVisible(false);
	           
	   }});       
	}

	

}
