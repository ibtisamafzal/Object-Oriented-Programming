package final_project;
import java.util.*;
import javax.swing.*;
public class view_Libraian {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      JFrame frame7 = new JFrame("View Libraian");
      frame7.setVisible(true);
      frame7.setLayout(null);
      frame7.setSize(500,500);
      
      
	}

}
